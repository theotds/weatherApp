package com.weather.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.weather.R

class ForecastAdapter(private var forecastItems: List<ForecastItem>) : RecyclerView.Adapter<ForecastAdapter.ForecastViewHolder>() {

    data class ForecastItem(val date: String, val temperature: Double)

    fun updateData(newItems: List<ForecastItem>) {
        forecastItems = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ForecastViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.forecast_item, parent, false)
        return ForecastViewHolder(view)
    }

    override fun onBindViewHolder(holder: ForecastViewHolder, position: Int) {
        val item = forecastItems[position]
        holder.dateTextView.text = item.date
        holder.temperatureTextView.text = "${item.temperature}°C"
    }

    override fun getItemCount(): Int = forecastItems.size

    class ForecastViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dateTextView: TextView = view.findViewById(R.id.tvForecastDate)
        val temperatureTextView: TextView = view.findViewById(R.id.tvForecastDescription)
    }
}
