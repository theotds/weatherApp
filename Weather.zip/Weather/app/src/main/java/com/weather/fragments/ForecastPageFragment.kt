package com.weather.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.weather.R
import com.weather.SharedViewModel
import com.weather.adapters.ForecastAdapter
import org.json.JSONObject

class ForecastPageFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private val sharedViewModel: SharedViewModel by activityViewModels()
    private lateinit var forecastAdapter: ForecastAdapter
    private lateinit var cityNameTextView: TextView  // Add this line

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.forecast_page_fragment, container, false)
        recyclerView = view.findViewById(R.id.recyclerViewForecast)
        recyclerView.layoutManager = LinearLayoutManager(context)
        forecastAdapter = ForecastAdapter(emptyList())
        recyclerView.adapter = forecastAdapter

        cityNameTextView = view.findViewById(R.id.tvCityName)  // Add this line

        sharedViewModel.forecastData.observe(viewLifecycleOwner) { forecastData ->
            if (forecastData != null) {
                updateUI(forecastData)
            }
        }

        return view
    }

    private fun updateUI(jsonData: String) {
        try {
            val jsonObject = JSONObject(jsonData)
            val cityObject = jsonObject.getJSONObject("city")
            val cityName = cityObject.getString("name")  // Get the city name
            cityNameTextView.text = cityName  // Set the city name

            val forecastList = jsonObject.getJSONArray("list")
            val forecastItems = mutableListOf<ForecastAdapter.ForecastItem>()

            for (i in 0 until forecastList.length()) {
                val item = forecastList.getJSONObject(i)
                val main = item.getJSONObject("main")
                val temp = main.getDouble("temp")
                val date = item.getString("dt_txt")

                forecastItems.add(ForecastAdapter.ForecastItem(date, temp))
            }

            forecastAdapter.updateData(forecastItems)
        } catch (e: Exception) {
            Log.e("WeatherApp", "Error updating forecast UI", e)
        }
    }
}
