package com.weather.fragments

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.weather.R

class FavoriteCitiesAdapter(
    private val favoriteCities: List<MainPageFragment.FavoriteCity>,
    private val onSelect: (Double, Double) -> Unit,
    private val onRemove: (MainPageFragment.FavoriteCity) -> Unit
) : RecyclerView.Adapter<FavoriteCitiesAdapter.FavoriteCityViewHolder>() {

    inner class FavoriteCityViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cityName: TextView = view.findViewById(R.id.tvCityName)
        val selectButton: Button = view.findViewById(R.id.btnSelect)
        val removeButton: Button = view.findViewById(R.id.btnRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteCityViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.favorite_city_item, parent, false)
        return FavoriteCityViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteCityViewHolder, position: Int) {
        val city = favoriteCities[position]
        holder.cityName.text = city.name
        holder.selectButton.setOnClickListener {
            onSelect(city.lat, city.lon)
        }
        holder.removeButton.setOnClickListener {
            onRemove(city)
        }
    }

    override fun getItemCount(): Int = favoriteCities.size
}
