package com.weather.fragments

import android.app.AlertDialog
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.weather.R
import com.weather.SharedViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

class MainPageFragment : Fragment() {
    private lateinit var locationName: TextView
    private lateinit var coordinates: TextView
    private lateinit var currentTime: TextView
    private lateinit var temperature: TextView
    private lateinit var pressure: TextView
    private lateinit var weatherDescription: TextView
    private lateinit var weatherIcon: ImageView
    private lateinit var cityInput: EditText
    private lateinit var searchButton: Button
    private lateinit var unitSwitch: Switch
    private lateinit var saveFavoriteButton: Button
    private lateinit var switchFavoriteButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var refreshRunnable: Runnable
    private var tempCelsius: Double = 0.0
    private var favoriteCities = mutableListOf<FavoriteCity>()  // List to store FavoriteCity objects

    private val sharedViewModel: SharedViewModel by activityViewModels() // Inject SharedViewModel

    data class FavoriteCity(val name: String, val country: String, val lat: Double, val lon: Double)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.main_page_fragment, container, false)
        locationName = view.findViewById(R.id.tvLocationName)
        coordinates = view.findViewById(R.id.tvCoordinates)
        currentTime = view.findViewById(R.id.tvTime)
        temperature = view.findViewById(R.id.tvTemperature)
        pressure = view.findViewById(R.id.tvPressure)
        weatherDescription = view.findViewById(R.id.tvWeatherDescription)
        weatherIcon = view.findViewById(R.id.ivWeatherIcon)
        cityInput = view.findViewById(R.id.tvCityInput)
        searchButton = view.findViewById(R.id.btnSearch)
        unitSwitch = view.findViewById(R.id.switchUnits)
        saveFavoriteButton = view.findViewById(R.id.btnSaveFavorite)
        switchFavoriteButton = view.findViewById(R.id.btnSwitchFavorite)

        searchButton.setOnClickListener {
            val city = cityInput.text.toString()
            if (city.isNotEmpty()) {
                fetchCities(city)
            }
        }

        saveFavoriteButton.setOnClickListener {
            saveFavoriteCity()
        }

        switchFavoriteButton.setOnClickListener {
            showFavoriteCities()
        }

        unitSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Convert to Fahrenheit
                val tempFahrenheit = (tempCelsius * 9 / 5) + 32
                temperature.text = String.format("%.1f°F", tempFahrenheit)
            } else {
                // Show Celsius
                temperature.text = String.format("%.1f°C", tempCelsius)
            }
        }

        // Load the last searched city's coordinates and weather data
        loadLastSearchedCity()
        loadFavoriteCities()

        return view
    }

    override fun onResume() {
        super.onResume()
        startPeriodicRefresh()
    }

    override fun onPause() {
        super.onPause()
        stopPeriodicRefresh()
    }

    private fun startPeriodicRefresh() {
        refreshRunnable = Runnable {
            if (isOnline()) {
                loadLastSearchedCity()
            } else {
                loadLastWeatherData()
            }
            handler.postDelayed(refreshRunnable, 20 * 60 * 1000) // 20 minutes
        }
        handler.post(refreshRunnable)
    }

    private fun stopPeriodicRefresh() {
        handler.removeCallbacks(refreshRunnable)
    }

    private fun fetchCities(city: String) {
        if (!isOnline()) {
            Toast.makeText(context, "No internet connection. Using last saved data.", Toast.LENGTH_SHORT).show()
            loadLastWeatherData()
            return
        }

        Thread {
            try {
                val apiKey = "d5a8f7b2049bda4c408e0c36eca81c66"  // Replace with your real API key
                val encodedCity = URLEncoder.encode(city, "UTF-8")
                val limit = 5
                val url = URL("https://api.openweathermap.org/geo/1.0/direct?q=$encodedCity&limit=$limit&appid=$apiKey")
                val urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.requestMethod = "GET"

                val inputStream = urlConnection.inputStream
                val reader = BufferedReader(InputStreamReader(inputStream))
                val response = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }

                // Log the full response
                Log.d("WeatherApp", "City data: $response")

                showCitySelection(response.toString())

                inputStream.close()
                urlConnection.disconnect()
            } catch (e: Exception) {
                Log.e("WeatherApp", "Error fetching city data", e)
            }
        }.start()
    }

    private fun showCitySelection(jsonData: String) {
        activity?.runOnUiThread {
            try {
                val citiesArray = JSONArray(jsonData)

                if (citiesArray.length() == 0) {
                    Toast.makeText(context, "No cities found", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }

                val cities = mutableListOf<String>()
                val cityData = mutableListOf<JSONObject>()
                for (i in 0 until citiesArray.length()) {
                    val city = citiesArray.getJSONObject(i)
                    val cityName = city.getString("name")
                    val country = city.getString("country")
                    val state = if (city.has("state")) city.getString("state") else ""
                    cities.add("$cityName, $state, $country")
                    cityData.add(city)
                }

                AlertDialog.Builder(requireContext())
                    .setTitle("Select a City")
                    .setItems(cities.toTypedArray()) { _, which ->
                        val selectedCity = cityData[which]
                        val lat = selectedCity.getDouble("lat")
                        val lon = selectedCity.getDouble("lon")
                        fetchWeatherByCoordinates(lat, lon)

                        // Save the last searched city's coordinates
                        saveLastSearchedCity(lat, lon)
                    }
                    .show()

            } catch (e: Exception) {
                Log.e("WeatherApp", "Error showing city selection", e)
            }
        }
    }

    private fun fetchWeatherByCoordinates(lat: Double, lon: Double) {
        if (!isOnline()) {
            Toast.makeText(context, "No internet connection. Using last saved data.", Toast.LENGTH_SHORT).show()
            loadLastWeatherData()
            return
        }

        Thread {
            try {
                val apiKey = "d5a8f7b2049bda4c408e0c36eca81c66"  // Replace with your real API key
                val url = URL("https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric")
                val urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.requestMethod = "GET"

                val inputStream = urlConnection.inputStream
                val reader = BufferedReader(InputStreamReader(inputStream))
                val response = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }

                // Parse JSON and update UI
                updateUI(response.toString(), lat, lon)

                // Fetch forecast data
                fetchForecastData(lat, lon)

                inputStream.close()
                urlConnection.disconnect()
            } catch (e: Exception) {
                Log.e("WeatherApp", "Error fetching weather data", e)
            }
        }.start()
    }

    private fun saveForecastData(jsonData: String) {
        val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
        with(sharedPref.edit()) {
            putString("LAST_FORECAST_DATA", jsonData)
            apply()
        }
        sharedViewModel.setForecastData(jsonData)
    }

    private fun updateUI(jsonData: String, lat: Double, lon: Double) {
        activity?.runOnUiThread {
            try {
                val jsonObject = JSONObject(jsonData)
                val weatherArray = jsonObject.getJSONArray("weather")
                val weather = weatherArray.getJSONObject(0)
                val main = jsonObject.getJSONObject("main")
                val sys = jsonObject.getJSONObject("sys")

                tempCelsius = main.getDouble("temp")
                val pressure = main.getInt("pressure")
                val description = weather.getString("description")
                val icon = weather.getString("icon")
                val country = sys.getString("country")

                locationName.text = "${jsonObject.getString("name")}, $country"
                coordinates.text = "Coordinates: $lat, $lon"
                currentTime.text = "Time: ${getCurrentTime()}"
                this.pressure.text = "Pressure: ${pressure} hPa"
                weatherDescription.text = description

                if (unitSwitch.isChecked) {
                    val tempFahrenheit = (tempCelsius * 9 / 5) + 32
                    temperature.text = String.format("%.1f°F", tempFahrenheit)
                } else {
                    temperature.text = String.format("%.1f°C", tempCelsius)
                }

                val iconUrl = "https://openweathermap.org/img/wn/${icon}@2x.png"
                Picasso.get().load(iconUrl).into(weatherIcon)

                // Save the weather data
                saveLastWeatherData(jsonData)

                // Update the SharedViewModel
                sharedViewModel.setWeatherData(jsonData)
            } catch (e: Exception) {
                Log.e("WeatherApp", "Error updating UI", e)
            }
        }
    }

    private fun getCurrentTime(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date())
    }

    private fun saveLastSearchedCity(lat: Double, lon: Double) {
        val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
        with(sharedPref.edit()) {
            putString("LAST_SEARCHED_LAT", lat.toString())
            putString("LAST_SEARCHED_LON", lon.toString())
            apply()
        }
    }

    private fun loadLastSearchedCity() {
        val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
        val lastSearchedLat = sharedPref.getString("LAST_SEARCHED_LAT", null)
        val lastSearchedLon = sharedPref.getString("LAST_SEARCHED_LON", null)
        if (lastSearchedLat != null && lastSearchedLon != null) {
            fetchWeatherByCoordinates(lastSearchedLat.toDouble(), lastSearchedLon.toDouble())
        }
    }

    private fun saveLastWeatherData(jsonData: String) {
        val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
        with(sharedPref.edit()) {
            putString("LAST_WEATHER_DATA", jsonData)
            apply()
        }
    }

    private fun loadLastWeatherData() {
        val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
        val lastWeatherData = sharedPref.getString("LAST_WEATHER_DATA", null)
        if (lastWeatherData != null) {
            // Use dummy coordinates because we don't need them for displaying the data
            updateUI(lastWeatherData, 0.0, 0.0)
        }
    }

    private fun saveFavoriteCity() {
        val cityName = locationName.text.toString().split(",")[0].trim()
        val country = locationName.text.toString().split(",")[1].trim()
        val lat = coordinates.text.split(":")[1].split(",")[0].trim().toDouble()
        val lon = coordinates.text.split(":")[1].split(",")[1].trim().toDouble()
        favoriteCities.add(FavoriteCity(cityName, country, lat, lon))
        saveFavoriteCitiesToPreferences()
        Toast.makeText(context, "City added to favorites", Toast.LENGTH_SHORT).show()
    }

    private fun saveFavoriteCitiesToPreferences() {
        val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
        val editor = sharedPref.edit()
        val favoriteCitiesString = favoriteCities.joinToString(";") { "${it.name},${it.country},${it.lat},${it.lon}" }
        editor.putString("FAVORITE_CITIES", favoriteCitiesString)
        editor.apply()
    }

    private fun loadFavoriteCities() {
        val sharedPref = activity?.getPreferences(Context.MODE_PRIVATE) ?: return
        val favoriteCitiesString = sharedPref.getString("FAVORITE_CITIES", "") ?: ""
        if (favoriteCitiesString.isNotEmpty()) {
            favoriteCities = favoriteCitiesString.split(";").map {
                val parts = it.split(",")
                FavoriteCity(parts[0], parts[1], parts[2].toDouble(), parts[3].toDouble())
            }.toMutableList()
        }
    }

    private fun showFavoriteCities() {
        if (favoriteCities.isEmpty()) {
            Toast.makeText(context, "No favorite cities saved", Toast.LENGTH_SHORT).show()
            return
        }

        val adapter = FavoriteCitiesAdapter(
            favoriteCities,
            onSelect = { lat, lon ->
                fetchWeatherByCoordinates(lat, lon)
                saveLastSearchedCity(lat, lon)
            },
            onRemove = {
                city -> removeFavoriteCity(city)
            }
        )

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.favorite_city_dialog, null)
        val recyclerView = dialogView.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        AlertDialog.Builder(requireContext())
            .setTitle("Favorite Cities")
            .setView(dialogView)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun removeFavoriteCity(city: FavoriteCity) {
        favoriteCities.remove(city)
        saveFavoriteCitiesToPreferences()
        Toast.makeText(context, "${city.name} removed from favorites", Toast.LENGTH_SHORT).show()
    }

    private fun fetchForecastData(lat: Double, lon: Double) {
        if (!isOnline()) {
            Toast.makeText(context, "No internet connection. Unable to fetch forecast data.", Toast.LENGTH_SHORT).show()
            return
        }

        Thread {
            try {
                val apiKey = "d5a8f7b2049bda4c408e0c36eca81c66"  // Replace with your real API key
                val url = URL("https://api.openweathermap.org/data/2.5/forecast?lat=$lat&lon=$lon&appid=$apiKey&units=metric")
                val urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.requestMethod = "GET"

                val inputStream = urlConnection.inputStream
                val reader = BufferedReader(InputStreamReader(inputStream))
                val response = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }

                val jsonData = response.toString()
                // Save forecast data
                saveForecastData(jsonData)

                inputStream.close()
                urlConnection.disconnect()
            } catch (e: Exception) {
                Log.e("WeatherApp", "Error fetching forecast data", e)
            }
        }.start()
    }

    private fun isOnline(): Boolean {
        val connectivityManager = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false
        return activeNetwork.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
