package com.weather

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SharedViewModel : ViewModel() {
    private val _weatherData = MutableLiveData<String>()
    val weatherData: LiveData<String> get() = _weatherData

    private val _forecastData = MutableLiveData<String>()
    val forecastData: LiveData<String> get() = _forecastData

    fun setWeatherData(data: String) {
        _weatherData.postValue(data)
    }

    fun setForecastData(data: String) {
        _forecastData.postValue(data)
    }
}
