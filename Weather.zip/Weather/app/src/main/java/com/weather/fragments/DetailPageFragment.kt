package com.weather.fragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.squareup.picasso.Picasso
import com.weather.R
import com.weather.SharedViewModel
import org.json.JSONObject

class DetailPageFragment : Fragment() {

    private val sharedViewModel: SharedViewModel by activityViewModels()

    private lateinit var windSpeed: TextView
    private lateinit var windDirection: TextView
    private lateinit var humidity: TextView
    private lateinit var visibility: TextView
    private lateinit var cityName: TextView
    private lateinit var temperature: TextView
    private lateinit var pressure: TextView
    private lateinit var weatherDescription: TextView
    private lateinit var weatherIcon: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.detail_page_fragment, container, false)
        windSpeed = view.findViewById(R.id.tvWindSpeed)
        windDirection = view.findViewById(R.id.tvWindDirection)
        humidity = view.findViewById(R.id.tvHumidity)
        visibility = view.findViewById(R.id.tvVisibility)
        cityName = view.findViewById(R.id.tvCityNameDetail)
        temperature = view.findViewById(R.id.tvTemperatureDetail)
        pressure = view.findViewById(R.id.tvPressureDetail)
        weatherDescription = view.findViewById(R.id.tvWeatherDescriptionDetail)
        weatherIcon = view.findViewById(R.id.ivWeatherIconDetail)

        // Observe weather data from SharedViewModel
        sharedViewModel.weatherData.observe(viewLifecycleOwner) { weatherData ->
            updateUI(weatherData)
        }

        return view
    }

    private fun updateUI(jsonData: String) {
        activity?.runOnUiThread {
            try {

                val jsonObject = JSONObject(jsonData)
                val weatherArray = jsonObject.getJSONArray("weather")
                val weather = weatherArray.getJSONObject(0)
                val main = jsonObject.getJSONObject("main")
                val wind = jsonObject.getJSONObject("wind")
                val visibilityValue = jsonObject.getInt("visibility")
                val icon = weather.getString("icon")


                val temp = main.getDouble("temp")
                temperature.text = "Temperature: ${temp}°C";
                windSpeed.text = "Wind Speed: ${wind.getDouble("speed")} m/s"
                windDirection.text = "Wind Direction: ${wind.getInt("deg")}°"
                humidity.text = "Humidity: ${main.getInt("humidity")}%"
                visibility.text = "Visibility: ${visibilityValue / 1000.0} km"
                cityName.text = jsonObject.getString("name")
                weatherDescription.text = weather.getString("description")
                pressure.text = "Pressure: ${main.getInt("pressure")} hPa"

                val iconUrl = "https://openweathermap.org/img/wn/${icon}@2x.png"
                Picasso.get().load(iconUrl).into(weatherIcon)
            } catch (e: Exception) {
                Log.e("WeatherApp", "Error updating UI", e)
            }
        }
    }
}
